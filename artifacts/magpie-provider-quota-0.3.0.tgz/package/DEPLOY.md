# Magpie Provider Quota 服务器部署

推荐把插件装进服务器现有的 Magpie，再用 Magpie Web 打开页面。
浏览器通过 Magpie 的服务代理访问插件，不会访问浏览器设备自己的 `127.0.0.1:3497`。

```text
浏览器 → SSH 隧道或 HTTPS → Magpie Web → 插件服务（服务器 127.0.0.1:3497）
                                               ↓
                                         服务器 Magpie 额度
```

## 1. 上传并安装

在本机上传发布包，替换实际服务器地址：

```sh
scp artifacts/magpie-provider-quota-0.3.0.tgz user@server:~/
```

在服务器上，以运行 Magpie 的同一个用户执行：

```sh
mkdir -p ~/magpie-plugins/provider-quota
tar -xzf ~/magpie-provider-quota-0.3.0.tgz \
  -C ~/magpie-plugins/provider-quota --strip-components=1
magpie plugin add ~/magpie-plugins/provider-quota
```

插件目录需要保留。Magpie 从该位置加载文件。
使用已有的账号和供应商配置，不需要复制本机的登录凭据或重新创建代理供应商。
插件宿主由 Magpie 管理，无需额外运行 Node、PM2 或另一个容器。

## 2. 开启 Magpie Web

如果现有 Magpie 已由 `magpie daemon` 管理：

```sh
magpie daemon web on
magpie status
```

保留现有监听地址和端口。`magpie daemon web on` 输出的链接包含登录凭证。

如果还没有守护服务，可以在确认现有手动启动实例已退出后安装：

```sh
magpie daemon install --web --addr 127.0.0.1:3430
magpie daemon start
magpie status
```

如果是自行维护的 systemd 或容器，保留原来的进程管理方式，
在原有 Magpie 启动命令中开启 Web，例如：

```sh
magpie serve --web=127.0.0.1:3430
```

以上为不同运行方式，选择一种即可，不需要同时启动多份 Magpie。
非 `magpie daemon` 托管时不要另行执行 `daemon install`。

## 3. 从电脑访问

个人使用可以直接做 SSH 转发。以下假设 Magpie Web 的实际端口是 3430；
如果步骤 2 输出其他端口，替换命令右侧的 3430：

```sh
ssh -N -L 3430:127.0.0.1:3430 user@server
```

在本机浏览器打开步骤 2 的登录链接。若本地 3430 已被占用，可改用：

```sh
ssh -N -L 13430:127.0.0.1:3430 user@server
```

再把登录链接中的端口改成 13430。登录后点击侧边栏「账号额度」。
插件的 3497 端口留在服务器回环地址，由 Magpie Web 代理，不用另外转发。

## 可选：通过域名访问

将已有 HTTPS 反向代理指向 Magpie Web 的端口，而不是插件的 3497 端口。
例如已有 Caddy 时：

```caddyfile
magpie.example.com {
    reverse_proxy 127.0.0.1:3430
}
```

给 Magpie 服务进程设置：

```text
MAGPIE_WEB_URL=https://magpie.example.com
```

重启你实际使用的 Magpie 服务，使链接使用此域名。继续使用 Magpie 自己的 Web 登录，
无需为插件另做一套登录。保留完整的路径、查询参数和请求头，不改写插件的服务路径。

## 数据接入与更新

订阅需要先在这台服务器的 Magpie「订阅」中接入，并取得额度读数。
支持 Kiro、Claude、ChatGPT / Codex、Copilot、Gemini CLI 及其他由 Magpie 插件提供的订阅。
例如 ChatGPT / Codex 可以通过 CLI 接入：

```sh
magpie accounts add codex
```

已有账号不必重复添加。新增订阅只要被这台 Magpie 的额度接口返回，就会在下次刷新自动显示。
本机已接入但服务器尚未接入的账号不会自动跨机器同步。
页面优先按 Magpie 返回的订阅、密钥套餐、API 余额类型分类，并保留各服务的全部额度窗口。
旧记录未标明类型时兼容常见订阅；无法确认的读数显示在「其他额度」。
第三方 API 余额使用服务器 Magpie 已配置的余额读取结果。
供应商未提供余额读数时，先配置 Magpie 的供应商余额探测。
已知余额和本地累计消费不能推算充值、退款或站外消费，页面不会把它们当作真实余额。

页面每 60 秒重读 Magpie 的记录，不主动请求供应商或切换账号。
点击刷新也只重读记录；供应商最新额度由 Magpie 更新。

## 更新插件与检查

将新发布包解压到相同目录，然后在 Magpie 插件列表关闭再开启此插件，
或在适合的时机重启你已有的 Magpie 服务。

```sh
magpie plugin --json
magpie status
```

若旧版本 Magpie Web 没有提供 `magpie.service`，先升级到支持页面服务代理的版本，
或使用独立页面加 SSH 转发插件端口作为后备。页面会明确提示缺少服务代理，
不会把服务器插件误连到浏览器设备的回环地址。
